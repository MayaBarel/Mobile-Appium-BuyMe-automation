package MobileProject;

import com.aventstack.extentreports.ExtentReports;
import com.aventstack.extentreports.ExtentTest;
import com.aventstack.extentreports.MediaEntityBuilder;
import com.aventstack.extentreports.Status;
import com.aventstack.extentreports.reporter.ExtentHtmlReporter;
import io.appium.java_client.MobileBy;
import io.appium.java_client.MobileElement;
import io.appium.java_client.android.AndroidDriver;
import io.appium.java_client.remote.MobileCapabilityType;
import org.junit.AfterClass;
import org.junit.BeforeClass;
import org.junit.FixMethodOrder;
import org.junit.Test;
import org.junit.runners.MethodSorters;
import org.openqa.selenium.remote.DesiredCapabilities;
import org.xml.sax.SAXException;

import javax.xml.parsers.ParserConfigurationException;
import java.io.IOException;
import java.net.URL;
import java.util.Random;
import java.util.concurrent.TimeUnit;

@FixMethodOrder(MethodSorters.NAME_ASCENDING)

public class Main {

    static AndroidDriver<MobileElement> driver;

    // create the report object, path and name
    private static ExtentReports extent = new ExtentReports();
    private static ExtentTest test = extent.createTest("MyFirstTest", "Sample description");
    private static String reportPath = "C:\\Maya\\JAVA\\Mobile\\src\\MobileProject\\extent.html";
    private static String folderPath = "C:\\Maya\\JAVA\\Mobile\\src\\screens";

    @BeforeClass
    public static void setUp() throws IOException, ParserConfigurationException, SAXException {

        DesiredCapabilities capabilities = new DesiredCapabilities();
        capabilities.setCapability(MobileCapabilityType.PLATFORM_NAME, ConstantsMobile.android);
        capabilities.setCapability(MobileCapabilityType.DEVICE_NAME, ConstantsMobile.androidDevice);
        String packageName = ConstantsMobile.getData(ConstantsMobile.getDataPackege);
        String appActivityName = ConstantsMobile.getData(ConstantsMobile.getDataActivity);


        capabilities.setCapability(ConstantsMobile.appPackage, packageName);
        capabilities.setCapability(ConstantsMobile.appActivity, appActivityName);
        capabilities.setCapability(MobileCapabilityType.NEW_COMMAND_TIMEOUT, 120);
        capabilities.setCapability(MobileCapabilityType.NO_RESET, true);
        driver = new AndroidDriver(new URL(ConstantsMobile.androidDriver), capabilities);
        driver.manage().timeouts().implicitlyWait(30, TimeUnit.SECONDS);

        //Report
        ExtentHtmlReporter htmlReporter = new ExtentHtmlReporter(reportPath);
        extent.attachReporter(htmlReporter);
        extent.setSystemInfo("Environment", "Production");
        // log information into the report
        test.log(Status.INFO, "Connecting driver");




    }

    @Test
    public void test01_MobileRegistrationPage() {
        //Click on Google button
        driver.findElement(MobileBy.id(ConstantsMobile.googleButton)).click();
        // add screenshot
        try {
            test.pass("Registration", MediaEntityBuilder.createScreenCaptureFromPath(ConstantsMobile.takeScreenShot(folderPath + new Random())).build());
        } catch (IOException e) {
            e.printStackTrace();
        }
    }



    @Test
    public void test02_MobileHomeScreen() {


        new MobileHomeScreen().chooseCategory();
        new MobileHomeScreen().business();


        // add screenshot
        try {
            test.pass("MobileHomeScreen", MediaEntityBuilder.createScreenCaptureFromPath(ConstantsMobile.takeScreenShot(folderPath + new Random())).build());
        } catch (IOException e) {
            e.printStackTrace();
        }

        driver.findElement(MobileBy.id(ConstantsMobile.budgetClick)).click();

    }

    @Test
    public void test03_MobileSenderReceiverInfoScreen() {
        new MobileSenderReceiverInfoScreen().SenderReceiverInfoScreen();

       new MobileSenderReceiverInfoScreen().dropDownList();

        new MobileSenderReceiverInfoScreen().blessing1();


        // Scrolling to an element by the element id
        driver.findElement(MobileBy.AndroidUIAutomator(ConstantsMobile.scroll
                + ConstantsMobile.scroll2));

   new MobileSenderReceiverInfoScreen().Sender();


        // add screenshot
        try {
            test.pass("MobileSenderReceiverInfo", MediaEntityBuilder.createScreenCaptureFromPath(ConstantsMobile.takeScreenShot(folderPath + new Random())).build());
        } catch (IOException e) {
            e.printStackTrace();
        }

    new MobileSenderReceiverInfoScreen().Next();
    }



    @Test
    public void test04_MobileHowToSendScreen() {

       new MobileHowToSendScreen().radioButton();

        new MobileHowToSendScreen().email();

        // Scrolling to an element by the element id

        driver.findElement(MobileBy.AndroidUIAutomator(ConstantsMobile.scroll
                + ConstantsMobile.scroll3));
        // add screenshot
        try {
            test.pass("MobileHowToSend", MediaEntityBuilder.createScreenCaptureFromPath(ConstantsMobile.takeScreenShot(folderPath + new Random())).build());
        } catch (IOException e) {
            e.printStackTrace();
        }

     new MobileHowToSendScreen().submitMore();

    }


    @AfterClass
    public static void tearDown(){
        driver.quit();
        extent.flush();

    }


}

