package MobileProject;

import org.apache.commons.io.FileUtils;
import org.openqa.selenium.OutputType;
import org.openqa.selenium.TakesScreenshot;
import org.w3c.dom.Document;
import org.xml.sax.SAXException;

import javax.xml.parsers.DocumentBuilder;
import javax.xml.parsers.DocumentBuilderFactory;
import javax.xml.parsers.ParserConfigurationException;
import java.io.File;
import java.io.IOException;

public class ConstantsMobile {
    //private static AndroidDriver<MobileElement> driver;

//   Method Get Data
    static String getData(String keyName) throws ParserConfigurationException, IOException, SAXException {
        File configXmlFile = new File("C:\\Maya\\JAVA\\Mobile\\src\\Mobile.xml");
        //     "C:\Maya\JAVA\selenium_class8\src\ProjectSelenium\browser.xml"
        DocumentBuilderFactory dbFactory = DocumentBuilderFactory.newInstance();
        DocumentBuilder dBuilder = null;

        dBuilder = dbFactory.newDocumentBuilder();

        Document doc = null;

        assert dBuilder != null;
        doc = dBuilder.parse(configXmlFile);

        if (doc != null) {
            doc.getDocumentElement().normalize();
        }
        assert doc != null;
        return doc.getElementsByTagName(keyName).item(0).getTextContent();
    }


    //Befor class
    public static final String  android = "Android";
    public static final String androidDevice = "Android Device";
    public static final String getDataPackege = "PACKAGE";
    public static final String getDataActivity = "ACTIVITY";
    public static final String appPackage = "appPackage";
    public static final String appActivity = "appActivity";
    public static final String androidDriver = "http://0.0.0.0:4723/wd/hub/";
    public static final String path = "C:\\Maya\\JAVA\\Mobile\\src\\screens";

    //Click on Google button
    public static final String googleButton= "il.co.mintapp.buyme:id/googleButton";

//cards
    public static final String cards = "il.co.mintapp.buyme:id/i_shadow";
    //pick a business
    public static final String business = "il.co.mintapp.buyme:id/businessName";
    //gift budget
    public static final String budget = "il.co.mintapp.buyme:id/priceEditText";
    public static final String budget200 = "200";
    public static final String budgetClick = "il.co.mintapp.buyme:id/purchaseButton";


    //SenderReceiverInfoScreen
    public static final String SenderReceiverInfoScreen =  "il.co.mintapp.buyme:id/toEditText";
    public static final String receiver = "Itamar";
    public static final String receiverClick = "android:id/text1";


    //Select from dropdown
    public static final String dropDownList = "android:id/text1";

    //blessing
    public static final String blessingElement= "il.co.mintapp.buyme:id/blessEditText";
    public static final String blessing = "Thank you very much my prince";

//SCROLL
    public static final String scroll = "new UiScrollable(new UiSelector().";

    public static final String scroll2 = "scrollable(true)).scrollIntoView(new UiSelector().resourceId(\"il.co.mintapp.buyme:id/userFrom\"))";
    public static final String scroll3 = "scrollable(true)).scrollIntoView(new UiSelector().resourceId(\"il.co.mintapp.buyme:id/goNextButton\"))";


    //Sender name
    public static final String sender = "il.co.mintapp.buyme:id/userFrom";
    public static final String senderName = "Mam Maya";
    //next
    public static final String nextButton = "il.co.mintapp.buyme:id/goNextButton";

    public static final String radioButton = "il.co.mintapp.buyme:id/nowRadioButton";

    //email option

    public static final String emailOption = "android.widget.CheckBox";
    public static final String emailElement = "il.co.mintapp.buyme:id/description";
    public static final String emailAdress = "email@gmail.com";
    //Submit
    public static final String submit = "il.co.mintapp.buyme:id/goNextButton";

    // take scrrenshot and return picture path
    static String takeScreenShot(String ImagesPath) {
        TakesScreenshot takesScreenshot = (TakesScreenshot) Main.driver;
        File screenShotFile = takesScreenshot.getScreenshotAs(OutputType.FILE);
        File destinationFile = new File(ImagesPath + ".png");
        try {
            FileUtils.copyFile(screenShotFile, destinationFile);
        } catch (IOException e) {
            System.out.println(e.getMessage());
        }
        return ImagesPath + ".png";
    }



}
