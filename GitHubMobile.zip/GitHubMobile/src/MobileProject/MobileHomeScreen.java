package MobileProject;

import io.appium.java_client.MobileBy;
import io.appium.java_client.MobileElement;

import java.util.List;

public class MobileHomeScreen {

    public void chooseCategory() {
        //choose category
        List<MobileElement> cards = Main.driver.findElements(MobileBy.id(ConstantsMobile.cards));
        MobileElement oneCard = cards.get(0);
        oneCard.click();
    }
    public void business(){
        //pick a business
        List<MobileElement> business = Main.driver.findElements(MobileBy.id(ConstantsMobile.business));
        MobileElement businessCard = business.get(0);
        businessCard.click();

        //enter your gift budget
        Main.driver.findElement(MobileBy.id(ConstantsMobile.budget)).sendKeys(ConstantsMobile.budget200);



    }
}
