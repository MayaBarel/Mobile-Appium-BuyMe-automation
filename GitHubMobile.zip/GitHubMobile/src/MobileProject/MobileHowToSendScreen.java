package MobileProject;

import io.appium.java_client.MobileBy;
import io.appium.java_client.MobileElement;

import java.util.List;

public class MobileHowToSendScreen {


    public void radioButton() {
        //Press radio button "מיד אחרי"

        Main.driver.findElement(MobileBy.id(ConstantsMobile.radioButton)).click();

        //Pick Email option

        List<MobileElement> sendList = Main.driver.findElements(MobileBy.className(ConstantsMobile.emailOption));
        MobileElement Email = sendList.get(2);
        Email.click();
    }

    public void email() {
        //email
        Main.driver.findElement(MobileBy.id(ConstantsMobile.emailElement)).sendKeys(ConstantsMobile.emailAdress);
    }
        public void submitMore () {
            //click submit
            Main.driver.findElement(MobileBy.id(ConstantsMobile.submit)).click();
        }
    }
