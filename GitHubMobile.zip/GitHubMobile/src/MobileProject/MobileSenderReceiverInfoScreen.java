package MobileProject;

import io.appium.java_client.MobileBy;
import io.appium.java_client.MobileElement;

import java.util.List;

public class MobileSenderReceiverInfoScreen {


    public void SenderReceiverInfoScreen() {
        //SenderReceiverInfoScreen
        Main.driver.findElement(MobileBy.id(ConstantsMobile.SenderReceiverInfoScreen)).sendKeys(ConstantsMobile.receiver);
        Main.driver.findElement(MobileBy.id(ConstantsMobile.receiverClick)).click();


    }

    public void dropDownList() {
        //Select from dropdown
        List<MobileElement> dropDownList = Main.driver.findElements(MobileBy.id(ConstantsMobile.dropDownList));
        MobileElement selectEvent = dropDownList.get(2);
        selectEvent.click();
    }

    public void blessing1() {
        //Enter a blessing
        MobileElement blessing = Main.driver.findElement(MobileBy.id(ConstantsMobile.blessingElement));
        blessing.clear();
        blessing.sendKeys(ConstantsMobile.blessing);

        // hideKeyboard
        Main.driver.hideKeyboard();

    }

    public void Sender() {
        //Sender name
        MobileElement sender = Main.driver.findElement(MobileBy.id(ConstantsMobile.sender));
        sender.clear();
        sender.sendKeys(ConstantsMobile.senderName);

        Main.driver.hideKeyboard();

    }

    public void Next() {
        //press Next
        Main.driver.findElement(MobileBy.id(ConstantsMobile.nextButton)).click();
    }
}